# hostel/serializers.py
from rest_framework import serializers
from hostel.models import Student, Complaint, Challan, Payment, RentPaymentHistory, Contact


class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = "__all__"


class ComplaintSerializer(serializers.ModelSerializer):
    class Meta:
        model = Complaint
        fields = "__all__"


class ChallanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Challan
        fields = "__all__"


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = "__all__"


class RentPaymentHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = RentPaymentHistory
        fields = "__all__"


class ContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contact
        fields = "__all__"
