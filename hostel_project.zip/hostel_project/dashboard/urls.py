from django.urls import path
from . import views

urlpatterns = [
    # =====================
    # Dashboard Home
    # =====================
    path('', views.dashboard_home, name="dashboard_home"), 


    # =====================
    # Student Management
    # =====================
    path('students/', views.students, name='students'),
    path('students/add/', views.add_student, name='add_student'),
    path('students/edit/<int:id>/', views.edit_student, name='edit_student'),
    path('students/delete/<int:id>/', views.delete_student, name='delete_student'),


    # =====================
    # Complaint Management
    # =====================
    path("dashboard/complaints/", views.complaint_list, name="complaint_list"),
    path("dashboard/complaints/respond/<int:pk>/", views.respond_complaint, name="respond_complaint"),
    path("dashboard/complaints/delete/<int:pk>/", views.delete_complaint, name="delete_complaint"),


    # =====================
    # Challan Management
    # =====================
    path('challans/', views.challans, name='challans'),
    path('challans/add/', views.add_challan, name='add_challan'),
    path('challans/edit/<int:id>/', views.edit_challan, name='edit_challan'),
    path('challans/delete/<int:id>/', views.delete_challan, name='delete_challan'),


    # ==================
    # API ENDPOINTS 
    # ==================
    path('api/students/', views.api_students, name='api_students'),
    path('api/complaints/', views.api_complaints, name='api_complaints'),
    path('api/challans/', views.api_challans, name='api_challans'),
    path('api/payments/', views.api_payments, name='api_payments'),
    path('api/rent-history/', views.api_rent_history, name='api_rent_history'),
    path('api/contacts/', views.api_contacts, name='api_contacts'),
]
