from django import forms
from hostel.models import Student, Complaint, Challan, Payment

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = "__all__"

class ComplaintResponseForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ["response"]

class ChallanForm(forms.ModelForm):
    class Meta:
        model = Challan
        fields = "__all__"

class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = "__all__"
