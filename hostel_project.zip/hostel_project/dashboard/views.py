from django.shortcuts import render, redirect, get_object_or_404
from hostel.models import Student, Complaint, Challan, Payment, RentPaymentHistory, Contact
from .forms import StudentForm, ComplaintResponseForm, ChallanForm, PaymentForm
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required



from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .serializers import (
    StudentSerializer,
    ComplaintSerializer,
    ChallanSerializer,
    PaymentSerializer,
    RentPaymentHistorySerializer,
    ContactSerializer
)

# =========================
#   DASHBOARD HOME
# =========================
@staff_member_required
def dashboard_home(request):
    students_count = Student.objects.count()
    complaints_count = Complaint.objects.count()
    unpaid_challans = Challan.objects.filter(status="unpaid").count()
    context = {
        "students_count": students_count,
        "complaints_count": complaints_count,
        "unpaid_challans": unpaid_challans
    }
    return render(request, "dashboard/dashboard_home.html", context)


# =====================
#   STUDENT CRUD 
# =====================
@staff_member_required
def students(request):
    students = Student.objects.all().order_by('-id')
    return render(request, 'dashboard/students.html', {'students': students})


@staff_member_required
def add_student(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        gender = request.POST.get('gender')
        address = request.POST.get('address')
        room_no = request.POST.get('room_no')
        rent_price = request.POST.get('rent_price')
        rent_status = request.POST.get('rent_status') == "True"

        user = User.objects.create_user(
            username=email,
            email=email,
            password="student123"
        )

        Student.objects.create(
            user=user,
            name=name,
            email=email,
            phone=phone,
            gender=gender,
            address=address,
            room_no=room_no,
            rent_price=rent_price,
            rent_status=rent_status
        )
        return redirect('students')

    return render(request, 'dashboard/add_student.html')


@staff_member_required
def edit_student(request, id):
    student = get_object_or_404(Student, id=id)
    if request.method == "POST":
        student.name = request.POST.get('name')
        student.email = request.POST.get('email')
        student.phone = request.POST.get('phone')
        student.gender = request.POST.get('gender')
        student.address = request.POST.get('address')
        student.room_no = request.POST.get('room_no')
        student.rent_price = request.POST.get('rent_price')
        student.rent_status = request.POST.get('rent_status') == "True"
        student.save()
        return redirect('students')
    return render(request, 'dashboard/edit_student.html', {'student': student})


@staff_member_required
def delete_student(request, id):
    student = get_object_or_404(Student, id=id)
    student.user.delete()
    student.delete()
    return redirect('students')


# =========================
#   COMPLAINT MANAGEMENT
# =========================
@staff_member_required
def complaint_list(request):
    complaints = Complaint.objects.all()
    return render(request, "dashboard/complaint_list.html", {"complaints": complaints})


@staff_member_required
def delete_complaint(request, pk):
    complaint = get_object_or_404(Complaint, pk=pk)
    if request.method == "POST":
        complaint.delete()
        messages.success(request, "Complaint deleted successfully.")
    return redirect("complaint_list")


@staff_member_required
def respond_complaint(request, pk):
    complaint = get_object_or_404(Complaint, pk=pk)
    if request.method == "POST":
        form = ComplaintResponseForm(request.POST, instance=complaint)
        if form.is_valid():
            complaint.status = "Resolved"
            form.save()
            messages.success(request, "✅ Complaint responded successfully.")
            return redirect("complaint_list")
    else:
        form = ComplaintResponseForm(instance=complaint)

    return render(request, "dashboard/complaint_form.html", {
        "form": form,
        "complaint": complaint
    })


# =========================
#   CHALLAN MANAGEMENT
# =========================
@staff_member_required
def challans(request):
    challans = Challan.objects.select_related('student').all().order_by('-id')
    return render(request, 'dashboard/challans.html', {'challans': challans})


@staff_member_required
def add_challan(request):
    students = Student.objects.all().order_by('name')
    if request.method == "POST":
        student_id = request.POST.get('student')
        student = get_object_or_404(Student, id=student_id)
        month = request.POST.get('month')
        amount = request.POST.get('amount') or 42000
        due_date = request.POST.get('due_date')
        status = request.POST.get('status') or 'unpaid'
        payment_method = request.POST.get('payment_method') or None

        Challan.objects.create(
            student=student,
            month=month,
            amount=amount,
            due_date=due_date,
            status=status,
            payment_method=payment_method
        )
        return redirect('challans')

    return render(request, 'dashboard/add_challan.html', {'students': students})


@staff_member_required
def edit_challan(request, id):
    challan = get_object_or_404(Challan, id=id)
    if request.method == "POST":
        challan.month = request.POST.get('month')
        challan.amount = request.POST.get('amount')
        challan.due_date = request.POST.get('due_date')
        challan.status = request.POST.get('status')
        challan.payment_method = request.POST.get('payment_method') or None
        challan.save()


        student = challan.student
        # If latest challan is paid, set rent_status True; else False
        latest_challan = Challan.objects.filter(student=student).order_by('-id').first()
        student.rent_status = True if latest_challan.status == "paid" else False
        student.save()

        return redirect('challans')
    return render(request, 'dashboard/edit_challan.html', {'challan': challan})


@staff_member_required
def delete_challan(request, id):
    challan = get_object_or_404(Challan, id=id)
    challan.delete()
    return redirect('challans')


# =========================
#   API VIEWS (NEW – JSON)
# =========================

@api_view(['GET'])
def api_students(request):
    students = Student.objects.all()
    serializer = StudentSerializer(students, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def api_complaints(request):
    complaints = Complaint.objects.all()
    serializer = ComplaintSerializer(complaints, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def api_challans(request):
    challans = Challan.objects.all()
    serializer = ChallanSerializer(challans, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def api_rent_history(request):
    history = RentPaymentHistory.objects.all()
    serializer = RentPaymentHistorySerializer(history, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def api_payments(request):
    payments = Payment.objects.all()
    serializer = PaymentSerializer(payments, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def api_contacts(request):
    contacts = Contact.objects.all()
    serializer = ContactSerializer(contacts, many=True)
    return Response(serializer.data)


@api_view(['POST'])
def api_create_payment(request):
    serializer = PaymentSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def api_create_complaint(request):
    serializer = ComplaintSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)              

@api_view(['POST'])
def api_create_contact(request):            
    serializer = ContactSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def api_create_student(request):
    serializer = StudentSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def api_create_challan(request):        
    serializer = ChallanSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST']) 
def api_create_rent_history(request):        
    serializer = RentPaymentHistorySerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['DELETE'])
def api_delete_student(request, pk):    
    student = get_object_or_404(Student, pk=pk)
    student.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['DELETE'])
def api_delete_complaint(request, pk):
    complaint = get_object_or_404(Complaint, pk=pk)
    complaint.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)
@api_view(['DELETE'])
def api_delete_challan(request, pk):
    challan = get_object_or_404(Challan, pk=pk)
    challan.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['DELETE'])
def api_delete_payment(request, pk):
    payment = get_object_or_404(Payment, pk=pk)
    payment.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['DELETE'])
def api_delete_rent_history(request, pk):
    history = get_object_or_404(RentPaymentHistory, pk=pk)
    history.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)
@api_view(['DELETE'])
def api_delete_contact(request, pk):
    contact = get_object_or_404(Contact, pk=pk)
    contact.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['PUT'])
def api_update_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    serializer = StudentSerializer(student, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
def api_update_complaint(request, pk):
    complaint = get_object_or_404(Complaint, pk=pk)
    serializer = ComplaintSerializer(complaint, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
def api_update_challan(request, pk):
    challan = get_object_or_404(Challan, pk=pk)
    serializer = ChallanSerializer(challan, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
def api_update_payment(request, pk):    
    payment = get_object_or_404(Payment, pk=pk)
    serializer = PaymentSerializer(payment, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
def api_update_rent_history(request, pk):
    history = get_object_or_404(RentPaymentHistory, pk=pk)
    serializer = RentPaymentHistorySerializer(history, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
@api_view(['PUT'])
def api_update_contact(request, pk):
    contact = get_object_or_404(Contact, pk=pk)
    serializer = ContactSerializer(contact, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


