import random
import string   
from datetime import date
from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import User


# ============================
#   STUDENT MODEL
# ============================
class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    gender = models.CharField(max_length=10)
    address = models.TextField()

    room_no = models.CharField(max_length=10)
    rent_price = models.CharField(max_length=10, default="3000")

    rent_status = models.BooleanField(default=False)
    join_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} |-| {self.room_no}"


# ============================
#   COMPLAINT MODEL
# ============================
class Complaint(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    subject = models.CharField(max_length=100)
    msg = models.TextField()
    date = models.DateField(auto_now_add=True)

    status = models.CharField(max_length=20, default='Pending')
    response = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.student.name} |-| {self.subject} |-| {self.date} |-| {self.status}"


# ============================
#   RENT PAYMENT HISTORY
# ============================
class RentPaymentHistory(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)

    month = models.CharField(max_length=20)
    amount = models.DecimalField(max_digits=8, decimal_places=2)
    amount_paid = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    remaining_amount = models.DecimalField(max_digits=8, decimal_places=2, default=0)

    date_paid = models.DateField(null=True, blank=True)
    status = models.CharField(
        max_length=10,
        choices=[('paid', 'paid'), ('unpaid', 'unpaid')],
        default='unpaid'
    )

    def __str__(self):
        return f"{self.student.name} |-| {self.month} |-| {self.status}"


# ============================
#   CONTACT MODEL
# ============================
class Contact(models.Model):
    name = models.CharField(max_length=50)
    mobile_number = models.CharField(max_length=20)
    visitor_email = models.EmailField()

    msg = models.TextField(blank=True, null=True)
    contact_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} |-| {self.contact_date} |-| {self.visitor_email}"


# ============================
#   CHALLAN MODEL                   
# ============================

class Challan(models.Model):
    STATUS_CHOICES = (
        ("paid", "Paid"),
        ("unpaid", "Unpaid"),
    )

    PAYMENT_METHODS = (
    ("UBL", "UBL"),
    ("HBL", "HBL"),
    ("JazzCash", "JazzCash"),
    ("EasyPaisa", "EasyPaisa"),
)


    student = models.ForeignKey("Student", on_delete=models.CASCADE)
    challan_no = models.CharField(max_length=30, unique=True, blank=True)
    month = models.CharField(max_length=20)
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=42000)
    issue_date = models.DateField(auto_now_add=True)
    due_date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="unpaid")
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS, blank=True, null=True)  # <-- Added

    def __str__(self):
        return f"{self.challan_no} | {self.student.name}"

    def save(self, *args, **kwargs):
        if not self.challan_no:
            today = date.today()
            date_part = today.strftime("%Y%m%d")
            random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
            self.challan_no = f"CHLN-{date_part}-{random_part}"
        super().save(*args, **kwargs)


# ============================
#   PAYMENT MODEL
# ============================
class Payment(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    challan = models.ForeignKey(Challan, on_delete=models.CASCADE , null=True, blank=True)  # Link to the challan
    month = models.CharField(max_length=20)
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=50)  # Bank, Card, etc.
    payment_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.month} - {self.payment_method}"