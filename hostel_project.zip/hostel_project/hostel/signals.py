from django.db.models.signals import post_save
from django.dispatch import receiver
from datetime import date, timedelta
import uuid

from .models import Student, Challan

@receiver(post_save, sender=Student)
def create_challan_for_student(sender, instance, created, **kwargs):
    if created:
        Challan.objects.create(
            student=instance,
            challan_no=str(uuid.uuid4())[:8],
            month=date.today().strftime("%B"),
            amount=42000,
            due_date=date.today() + timedelta(days=15),
            status='unpaid'
        )
