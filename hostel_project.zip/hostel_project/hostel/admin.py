from django.contrib import admin
from .models import Contact, Student, Complaint, Payment, RentPaymentHistory, Challan
import csv
from django.http import HttpResponse

# ============================
#   STUDENT ADMIN
# ============================
@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('name', 'room_no', 'phone', 'email', 'gender', 'rent_price', 'rent_status', 'join_date')
    list_filter = ('rent_status', 'gender')
    search_fields = ('name', 'email', 'room_no')
    actions = ['export_as_csv']

    def export_as_csv(self, request, queryset):
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename=students.csv'
        writer = csv.writer(response)
        writer.writerow(['Name', 'Room No', 'Mobile', 'Email', 'Gender', 'Address', 'Join Date', 'Rent Price', 'Rent Status'])
        
        for student in queryset:
            writer.writerow([
                student.name, 
                student.room_no, 
                student.phone, 
                student.email, 
                student.gender, 
                student.address, 
                student.join_date,
                student.rent_price,
                "Paid" if student.rent_status else "Unpaid"
            ])
        return response

    export_as_csv.short_description = "Export Selected Students to CSV"

# ============================
#   COMPLAINT ADMIN
# ============================
@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ('student', 'subject', 'date', 'status')
    list_filter = ('status',)
    search_fields = ('student__name', 'subject')

# ============================
#   RENT PAYMENT HISTORY ADMIN
# ============================
@admin.register(RentPaymentHistory)
class RentPaymentHistoryAdmin(admin.ModelAdmin):
    list_display = ('student', 'month', 'amount', 'amount_paid', 'remaining_amount', 'status', 'date_paid')
    list_filter = ('status', 'month')
    search_fields = ('student__name', 'month')
    actions = ['mark_as_paid', 'mark_as_unpaid']

    def mark_as_paid(self, request, queryset):
        queryset.update(status='paid')
    mark_as_paid.short_description = "Mark selected payments as Paid"

    def mark_as_unpaid(self, request, queryset):
        queryset.update(status='unpaid')
    mark_as_unpaid.short_description = "Mark selected payments as Unpaid"

# ============================
#   CONTACT ADMIN
# ============================
@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'mobile_number', 'visitor_email', 'contact_date')
    search_fields = ('name', 'visitor_email')

# ============================
#   CHALLAN ADMIN
# ============================
@admin.register(Challan)
class ChallanAdmin(admin.ModelAdmin):
    list_display = ('challan_no', 'student', 'month', 'amount', 'status', 'issue_date', 'due_date', 'payment_method')
    list_filter = ('status', 'month', 'payment_method')
    search_fields = ('challan_no', 'student__name')
    actions = ['export_as_csv', 'mark_as_paid', 'mark_as_unpaid']

    def export_as_csv(self, request, queryset):
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename=challans.csv'
        writer = csv.writer(response)
        writer.writerow(['Challan No', 'Student', 'Month', 'Amount', 'Status', 'Issue Date', 'Due Date', 'Payment Method'])
        
        for challan in queryset:
            writer.writerow([
                challan.challan_no,
                challan.student.name,
                challan.month,
                challan.amount,
                challan.status,
                challan.issue_date,
                challan.due_date,
                challan.payment_method
            ])
        return response
    export_as_csv.short_description = "Export Selected Challans to CSV"

    def mark_as_paid(self, request, queryset):
        queryset.update(status='paid')
    mark_as_paid.short_description = "Mark selected challans as Paid"

    def mark_as_unpaid(self, request, queryset):
        queryset.update(status='unpaid')
    mark_as_unpaid.short_description = "Mark selected challans as Unpaid"

# ============================
#   PAYMENT ADMIN
# ============================
@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('student', 'challan', 'month', 'amount_paid', 'payment_method', 'payment_date')
    list_filter = ('payment_method', 'month')
    search_fields = ('student__name', 'month', 'challan__challan_no')
