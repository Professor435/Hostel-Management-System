from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth import authenticate, login, update_session_auth_hash, logout
from django.contrib import messages
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.utils.crypto import get_random_string
from django.template.loader import get_template, render_to_string
from datetime import date, timedelta, timezone
import csv
from xhtml2pdf import pisa
import pdfkit
from xhtml2pdf import pisa
from .models import Complaint, Contact, Student, RentPaymentHistory, Challan
import random , string

# ------------------------------
# STUDENT REGISTER VIEW  
# ------------------------------
def student_register(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        gender = request.POST.get("gender")
        address = request.POST.get("address")
        username = request.POST.get("username")
        password = request.POST.get("password")

        # Validation
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists. Please choose another.")
            return redirect("student_register")

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered.")
            return redirect("student_register")

        # Create User
        user = User.objects.create_user(
            username=username,
            email=email,
            password=password,
            first_name=name
        )

        # Create Student Profile
        Student.objects.create(
            user=user,
            name=name,
            email=email,
            phone=phone,
            gender=gender,
            address=address,
            room_no="Not Assigned"
        )

        messages.success(request, "Registration successful! Please login now.")
        return redirect("login")

    return render(request, "student_register.html")


#-------------------------
# GOGGLE LOGIN      
#-------------------------

@login_required
def google_login_redirect(request):
    student, created = Student.objects.get_or_create(
        user=request.user,
        defaults={
            "name": request.user.first_name or request.user.username,
            "email": request.user.email,
            "room_no": "Not Assigned"
        }
    )

    if created or not student.phone:
        messages.info(request, "Complete your profile.")
        return redirect("student_profile")

    return redirect("student_dashboard")






# ------------------------------------------------------------



@login_required(login_url='login')
def student_dashboard(request):
    try:
        student = Student.objects.get(user=request.user)
    except Student.DoesNotExist:
        messages.error(request, "Session expired or profile missing. Please login again.")
        logout(request)
        return redirect('login')

    return render(request, 'student_dashboard.html', {'student': student})


def landing(request):
    return render(request, "landing_page.html")


def home(request):
    return render(request, "index.html")


def rent(request):
    return render(request, "room&facilities.html")


def services(request):
    return render(request, "services.html")


def contact(request):
    if request.method == "POST":
        name = request.POST.get("name")
        num = request.POST.get("number")
        mail = request.POST.get("email")
        msg = request.POST.get("msg")

        Contact.objects.create(
            name=name,
            mobile_number=num,
            visitor_email=mail,
            msg=msg
        )
        messages.success(request, "Thanks for contacting us! We'll reach out soon.")
        return redirect("contact")

    return render(request, "contact.html")


# ------------------------------
# STUDENT LOGIN VIEW
# ------------------------------
def student_login(request):
    if request.user.is_authenticated:
        return redirect('student_dashboard')

    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, "Login Successful!")
            return redirect("student_dashboard")
        else:
            messages.error(request, "Invalid username or password")

    return render(request, "student_login.html")


def student_logout(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect('login')


def student_profile(request):
    try:
        student = Student.objects.get(user=request.user)
        return render(request, "student_profile.html", {'student': student})
    except Student.DoesNotExist:
        messages.error(request, "Session expired or profile missing. Please login again.")
        logout(request)
        return redirect('login')




@login_required
def edit_profile(request):
    try:
        student = Student.objects.get(user=request.user)
        if request.method == "POST":
            student.name = request.POST.get("name")
            student.email = request.POST.get("email")
            student.phone = request.POST.get("phone")
            student.gender = request.POST.get("gender")
            student.address = request.POST.get("address")
            student.room_no = request.POST.get("room_no")
            student.save()
            messages.success(request, "Profile updated successfully!")
            return redirect('student_profile')
        return render(request, "edit_profile.html", {'student': student})
    except Student.DoesNotExist:
        messages.error(request, "Session expired or profile missing. Please login again.")
        return redirect('login')



@login_required
def change_password(request):
    if request.method == "POST":
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # IMPORTANT
            messages.success(request, "Your password was successfully updated.")
            return redirect('student_dashboard')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = PasswordChangeForm(request.user)

    return render(request, 'change_password.html', {'form': form})



@login_required
def rent_status(request):
    try:
        student = get_object_or_404(Student, user=request.user)

        # Fetch rent and challan history
        rent_history = RentPaymentHistory.objects.filter(student=student).order_by('-date_paid')
        challan_history = Challan.objects.filter(student=student).order_by('-issue_date')

        # Determine rent status
        latest_rent = rent_history.first()
        latest_challan = challan_history.first()

        if (student.rent_status) or (latest_challan and latest_challan.status == 'paid'):
            rent_status = "Paid"
        else:
            rent_status = "Not paid"

    except Student.DoesNotExist:
        student = None
        rent_status = "Error"
        rent_history = []
        challan_history = []

    context = {
        'student': student,
        'rent_status': rent_status,
        'rent_history': rent_history,
        'challan_history': challan_history,
    }

    return render(request, 'rent_status.html', context)

@login_required(login_url='login')
def room_info(request):
    return render(request, "room_info.html")


def complaint(request):
    if request.method == "POST":
        sub = request.POST.get("sub")
        msg = request.POST.get("msg")

        student = get_object_or_404(Student, user=request.user)

        Complaint.objects.create(
            student=student,
            subject=sub,
            msg=msg,
        )

        messages.success(request, "Your complaint has been submitted.")
        return redirect("student_dashboard")
    return render(request, "complaint.html")


@login_required(login_url='login')
def complaint_history(request):
    student = get_object_or_404(Student, user=request.user)
    complaints = Complaint.objects.filter(student=student).order_by('-date')
    return render(request, 'complaint_history.html', {'complaints': complaints})


#------------------------
# CHALLAN GENERATION VIEW
#------------------------
@login_required
def challan(request):
    student = get_object_or_404(Student, user=request.user)

    challan_obj = (
        Challan.objects
        .filter(student=student)
        .order_by('-issue_date')
        .first()
    )

    if not challan_obj:
        return render(request, "challan.html", {
            "student": student,
            "no_challan": True
        })

    context = {
        "student": student,
        "challan": challan_obj,
        "challan_no": challan_obj.challan_no,
        "issued_date": challan_obj.issue_date,
        "due_date": challan_obj.due_date,
        "month": challan_obj.month,
        "amount": challan_obj.amount,
        "status": challan_obj.status.capitalize(),
    }

    # ✅ PDF DOWNLOAD
    if request.GET.get("pdf") == "1":
        template = get_template("challan_pdf.html")
        html = template.render(context)

        response = HttpResponse(content_type="application/pdf")
        response["Content-Disposition"] = 'attachment; filename="challan.pdf"'

        pisa.CreatePDF(html, dest=response)
        return response

    return render(request, "challan.html", context)









# ------------------------------
# Payment Options (Confirm Payment)
# ------------------------------
@login_required
def payment_options(request):
    student = get_object_or_404(Student, user=request.user)

    challan = Challan.objects.filter(student=student, status="unpaid").order_by('-issue_date').first()
    if not challan:
        messages.error(request, "No unpaid challan found.")
        return redirect('challan')

    if request.method == "POST":
        bank = request.POST.get("bank")
        if not bank:
            messages.error(request, "Please select a payment method.")
            return redirect('payment_options')

        # Mark challan as paid
        challan.status = "paid"
        challan.payment_method = bank
        challan.save()

        # Save payment history
        RentPaymentHistory.objects.create(
            student=student,
            month=challan.month,
            amount=challan.amount,
            amount_paid=challan.amount,
            remaining_amount=0,
            date_paid=challan.issue_date,
            status='paid'
        )

        messages.success(request, f"Payment successful via {bank}.")
        return redirect('payment_receipt')

    return render(request, "payment_options.html", {"challan": challan})


# ------------------------------
# HTML Payment Receipt
# ------------------------------
@login_required
def payment_receipt(request):
    student = request.user.student
    challan = student.challan_set.filter(status="paid").order_by('-issue_date').first()
    if not challan:
        messages.error(request, "No paid challan found.")
        return redirect('payment_options')

    return render(request, "payment_receipt.html", {"challan": challan})


# ------------------------------
# PDF Payment Receipt
# ------------------------------
@login_required
def payment_receipt_pdf(request, challan_id):
    challan = get_object_or_404(Challan, id=challan_id, status="paid")

    template_path = "payment_receipt_pdf.html"
    context = {"challan": challan}

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="receipt_{challan.challan_no}.pdf"'

    template = get_template(template_path)
    html = template.render(context)

    pisa_status = pisa.CreatePDF(html, dest=response)
    if pisa_status.err:
        return HttpResponse("Error generating PDF <pre>" + html + "</pre>")

    return response